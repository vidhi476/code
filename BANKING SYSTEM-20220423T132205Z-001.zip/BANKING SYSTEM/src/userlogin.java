import java.sql.*;
import javax.swing.JOptionPane;
public class userlogin extends javax.swing.JFrame  {
    public userlogin() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        accountnumber = new javax.swing.JTextField();
        ifsccode = new javax.swing.JTextField();
        create = new javax.swing.JButton();
        reset = new javax.swing.JButton();
        login1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 14)); 
        jLabel1.setText("ACCOUNT LOGIN");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(200, 30, 120, 17);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 12)); 
        jLabel2.setText("ACCOUNT NUMBER:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 120, 130, 14);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 12)); 
        jLabel3.setText("IFSC CODE:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(30, 200, 90, 14);
        jPanel1.add(accountnumber);
        accountnumber.setBounds(160, 110, 290, 30);
        jPanel1.add(ifsccode);
        ifsccode.setBounds(160, 190, 290, 30);

        create.setText("CREATE NEW ACCOUNT");
        create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createActionPerformed(evt);
            }
        });
        jPanel1.add(create);
        create.setBounds(200, 320, 210, 30);

        reset.setText("RESET");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        jPanel1.add(reset);
        reset.setBounds(320, 260, 80, 30);

        login1.setText("LOGIN");
        login1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login1ActionPerformed(evt);
            }
        });
        jPanel1.add(login1);
        login1.setBounds(200, 260, 80, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 502, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
        );

        pack();
    }

    private void createActionPerformed(java.awt.event.ActionEvent evt) {
        register r=new register();
        r.setVisible(true);
        this.dispose();
                  
    }

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {
        accountnumber.setText("");
        ifsccode.setText("");
    }

    private void login1ActionPerformed(java.awt.event.ActionEvent evt) {
        String s1=accountnumber.getText();
                  String s2=ifsccode.getText();
                  Accountdetails a = new Accountdetails();
                  boolean flag = false;
                    try
                    {
                       Class.forName("com.mysql.jdbc.Driver");
                       Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","admin","Pass@1234");
                       Statement stmt=con.createStatement();
                       String query="select accnumber,ifsc from accdetails where accnumber='"+s1+"' and ifsc='"+s2+"'";
                        ResultSet rs=stmt.executeQuery(query);
                        if(rs.next())
                       {
                           flag = true;
                           JOptionPane.showMessageDialog(null,"valid user");
                           Accountdetails t=new Accountdetails();
                           t.setVisible(true);
                           this.dispose();
                           String query1="select * from accdetails where accnumber='"+s1+"' and ifsc='"+s2+"'";
                        ResultSet rs1=stmt.executeQuery(query1);
                        while(rs1.next())
                        {
                            System.out.println(rs1.getString(1));
                            Accountdetails.name.setText(rs1.getString(1));
                            System.out.println(rs1.getString(2));
                            Accountdetails.dob.setText(rs1.getString(2));
                            System.out.println(rs1.getString(3));
                            Accountdetails.address.setText(rs1.getString(3));
                            System.out.println(rs1.getString(4));
                            Accountdetails.accnumber.setText(rs1.getString(4));
                            System.out.println(rs1.getString(5));
                            Accountdetails.ifsc.setText(rs1.getString(5));
                            System.out.println(rs1.getString(6));
                            Accountdetails.cif.setText(rs1.getString(6));
                            System.out.println(rs1.getString(7));
                            Accountdetails.phoneno.setText(rs1.getString(7));
                           }
                        }
                      
                       else
                       {
                       JOptionPane.showMessageDialog(null,"invalid user");
                       }
                    }
                catch(Exception ex)
                      {
                      }
    }
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(userlogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(userlogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(userlogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(userlogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new userlogin().setVisible(true);
            }
        });
    }

    private javax.swing.JTextField accountnumber;
    private javax.swing.JButton create;
    private javax.swing.JTextField ifsccode;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton login1;
    private javax.swing.JButton reset;
   
}
