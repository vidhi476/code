
public class Transactiondetails extends javax.swing.JFrame {
 public Transactiondetails() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        trans = new javax.swing.JTable();
        logout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("TRANSACTION DETAILS");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(230, 30, 170, 20);

        trans.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"179387", "27/08/16", "      50,000", "        -", "50,000.00"},
                {"938475", "30/08/16", "         -", "30,000", "20,000.00"},
                {"937459", "03/09/16", "65,000", "       -", "85,000.00"},
                {"937498", "06/09/16", "70,000", "       -", "1,55,000.00"},
                {"849837", "09/09/16", "         -", "40,000", "1,15,000.00"},
                {"374698", "15/09/16", "5,000", "       -", "1,20,000.00"},
                {"894839", "30/09/16", "         -", "30,000", "90,000.00"}
            },
            new String [] {
                "TRANSACTION ID", "TRANSACTION DATE", "CREDIT", "DEBIT", "TOTAL"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(trans);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(20, 80, 580, 140);

        logout.setText("LOGOUT");
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });
        getContentPane().add(logout);
        logout.setBounds(503, 250, 90, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {
       
        this.dispose();
        login s=new login();
        s.setVisible(true);
    }
    public static void main(String args[]) {
        
         
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Transactiondetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Transactiondetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Transactiondetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Transactiondetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Transactiondetails().setVisible(true);
            }
        });
    }

    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout;
    public static javax.swing.JTable trans;
    
}
