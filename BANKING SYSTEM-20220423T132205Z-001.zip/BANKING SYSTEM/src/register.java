import java.sql.*;
import javax.swing.JOptionPane;
public class register extends javax.swing.JFrame {
    public register() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        address = new javax.swing.JTextField();
        ifsc = new javax.swing.JTextField();
        name2 = new javax.swing.JTextField();
        phoneno = new javax.swing.JTextField();
        accno = new javax.swing.JTextField();
        dob = new javax.swing.JTextField();
        cancel = new javax.swing.JButton();
        reset = new javax.swing.JButton();
        create = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cif = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); 
        jLabel1.setText("CREATE NEW ACCOUNT");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(250, 30, 240, 40);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); 
        jLabel2.setText("NAME                                :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(50, 110, 140, 14);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); 
        jLabel3.setText("DATE OF BIRTH             :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(50, 160, 140, 14);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); 
        jLabel4.setText("ADDRESS                         :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(50, 210, 140, 14);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); 
        jLabel5.setText("ACCOUNT NUMBER      :");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(50, 270, 140, 14);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); 
        jLabel6.setText("IFSC CODE                      :");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(50, 320, 136, 14);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); 
        jLabel7.setText("PHONE NO                       :");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(50, 430, 140, 14);
        jPanel1.add(address);
        address.setBounds(210, 200, 490, 30);
        jPanel1.add(ifsc);
        ifsc.setBounds(210, 310, 490, 30);
        jPanel1.add(name2);
        name2.setBounds(210, 100, 490, 30);

        phoneno.setText("+91");
        jPanel1.add(phoneno);
        phoneno.setBounds(210, 420, 490, 30);
        jPanel1.add(accno);
        accno.setBounds(210, 260, 490, 30);
        jPanel1.add(dob);
        dob.setBounds(210, 150, 490, 30);

        cancel.setText("CANCEL");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
        jPanel1.add(cancel);
        cancel.setBounds(560, 500, 140, 40);

        reset.setText("RESET");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        jPanel1.add(reset);
        reset.setBounds(390, 500, 140, 40);

        create.setText("CREATE");
        create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createActionPerformed(evt);
            }
        });
        jPanel1.add(create);
        create.setBounds(220, 500, 140, 40);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); 
        jLabel8.setText("CIF CODE                         :");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(50, 370, 140, 14);
        jPanel1.add(cif);
        cif.setBounds(210, 360, 490, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 576, Short.MAX_VALUE)
        );

        pack();
    }

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {
        name2.setText("");
        dob.setText("");
        address.setText("");
        accno.setText("");
        ifsc.setText("");
        cif.setText("");
        phoneno.setText("");
    }

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {
        userlogin u=new userlogin();
        u.setVisible(true);
        this.dispose();
    }

    private void createActionPerformed(java.awt.event.ActionEvent evt) {
        String s1=name2.getText();
        String s2=dob.getText();
        String s3=address.getText();
        String s4=accno.getText();
        String s5=ifsc.getText();
        String s6=cif.getText();
        String s7=phoneno.getText();
        
                    try
                    {
                       Class.forName("com.mysql.jdbc.Driver");
                       Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","root");
                       Statement stmt=con.createStatement();
                       stmt.executeUpdate("insert into accdetails values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"')");  
                       JOptionPane.showMessageDialog(null,"created successfully");
                       }
                    
                    catch(Exception ex)
                      {
                          JOptionPane.showMessageDialog(null,"failed");
                      }
    }
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new register().setVisible(true);
            }
        });
    }

    
    private javax.swing.JTextField accno;
    private javax.swing.JTextField address;
    private javax.swing.JButton cancel;
    private javax.swing.JTextField cif;
    private javax.swing.JButton create;
    private javax.swing.JTextField dob;
    private javax.swing.JTextField ifsc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField name2;
    private javax.swing.JTextField phoneno;
    private javax.swing.JButton reset;
    
}
